package org.bboards.domains

class Owner {

    private String name;

    private String phone;

    private String address;

    private String notes;

    static mapWith = "mongo"

    static constraints = {
    }
}
